# Medical analyses

Medical Software will design a Java application to help persons monitor their health state. The application will store all the
analyses ever made for a person, regarding two medical markers: BMI (Body Mass Index) and BP (Blood Pressure). The
MedicalAnalysis class is abstract and stores the date and status (done or in_progress) of the analysis. BMI and BP are both
concrete classes.

Any type of analysis (BMI or a BP) can be added:
- The BMI measurement is characterized by a real value.
- The BP measurement is characterized by a systolic value and a diastolic value, both integers.

The MedicalAnalysisRepository is a generic class, which can store any type of medical analyses.

The application should provide a user interface allowing the following functionalities:
1. Add a new analysis. Read the type of analysis and the corresponding necessary information (2p). Values for any type of
analysis must be positive. Constructors or validators will impose the constraint and exceptions will be thrown in case
values are zero or negative (0.5p).
2. Show all analyses, with their correct information, sorted ascending by date. The sorting operation will use either the
Comparator or the Comparable interface. (2p)
3. At program start, all analyses are loaded from a binary file and each modification is automatically saved to the file. (2p)
4. Show all analyses in the past two months, which have a given status. The current month will be given by the user. If this
month is 1, only the analyses in the current month will be considered. Use the Java 8 Stream API to solve this feature (2p).
5. Provide JUnit tests for the filtering method of the Service class. (0.5p)

The application must use a layered architecture, inheritance and a generic repository class, as specified in the requirement
above. Otherwise, the maximum score for each requirement is 50% of the indicated score.
1p – of.
Allotted time: 60 minutes.
