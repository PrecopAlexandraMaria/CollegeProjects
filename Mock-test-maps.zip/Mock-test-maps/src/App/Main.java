package App;

import Domain.BMI;
import Domain.BP;
import Repository.*;
import Service.BMIService;
import Service.BPService;
import Ui.Console;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Main {
    public static IRepository<BMI> readSettingsInitRepositoryCardio() {
        IRepository<BMI> repo = new MemoryRepository<>();
        try {
            Properties properties = new Properties();
            properties.load(new FileReader("src/settings.properties"));
            String repoPath = properties.getProperty("RepoPath");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return repo;
    }

    public static IRepository<BP> readSettingsInitRepositoryStrength() {
        IRepository<BP> repo2 = new MemoryRepository<>();
        try {
            Properties properties = new Properties();
            properties.load(new FileReader("src/settings.properties"));
            String repoPath = properties.getProperty("RepoPath");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return repo2;
    }

    public static void main(String[] args) {
        IRepository<BMI> repo = readSettingsInitRepositoryCardio();
        IRepository<BP> repo2 = readSettingsInitRepositoryStrength();
        BMIService bmiserv = new BMIService(repo);
        BPService bpserv = new BPService(repo2);
        Console Ui = new Console(bmiserv,bpserv);
        Ui.run();
    }
}