package Domain;

import java.time.LocalDate;

public class BMI extends MedicalAnalysis{
        private double value;
        public BMI(LocalDate date, String status, double value){
            super(date, status);
            if(value<=0){
                this.value = 1;
                throw new IllegalArgumentException("Values for any type of analysis must be positive");
            }
            this.value = value;
        }

        public double getValue(){
            return this.value;
        }

        public void setValue(double value){
            this.value = value;
        }

        @Override
        public String toString(){
            return super.toString() + ',' + this.value;
        }
}
