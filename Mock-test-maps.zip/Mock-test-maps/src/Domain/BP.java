package Domain;

import java.util.Objects;
import java.time.LocalDate;

public class BP extends MedicalAnalysis{
    private int svalue;
    private int dvalue;

    public BP(LocalDate date, String status, int svalue, int dvalue){
        super(date, status);
        if(svalue <= 0 || dvalue <= 0){
            this.svalue = 1;
            this.dvalue = 1;
            throw new IllegalArgumentException("Values for any type of analysis must be positive");
        }
        this.svalue = svalue;
        this.dvalue = dvalue;
    }

    public int getSValue(){
        return this.svalue;
    }

    public void setSValue(int svalue){
        this.svalue = svalue;
    }

    public int getDValue(){
        return this.dvalue;
    }

    public void setDValue(int dvalue){
        this.svalue = dvalue;
    }

    @Override
    public String toString(){
        return super.toString() + ',' + this.svalue + ',' + this.dvalue;
    }
}
