package Domain;

import java.util.Objects;
import java.time.LocalDate;

abstract public class MedicalAnalysis implements Comparable<MedicalAnalysis>{
    protected LocalDate date;
    protected String status;

    public MedicalAnalysis(LocalDate date, String status) {
        this.date = date;
        this.status = status;
    }

    public LocalDate getDate(){
        return this.date;
    }

    public String getStatus(){
        return this.status;
    }

    public void setDate(LocalDate date){
        this.date = date;
    }

    public void setStatus(String status){
        this.status = status;
    }

    @Override
    public int compareTo(MedicalAnalysis other) {
        return this.date.compareTo(other.date);
    }

    @Override
    public String toString(){
        return this.date + "," + this.status;
    }

    @Override
    public boolean equals(Object other){
        if(this == other)
            return true;
        if(other == null || other.getClass() != this.getClass())
            return false;
        MedicalAnalysis ma = (MedicalAnalysis) other;
        return this.date == ma.date && this.status == ma.status;
    }

    @Override
    public int hashCode(){
        return Objects.hash(this.date, this.status);
    }
}
