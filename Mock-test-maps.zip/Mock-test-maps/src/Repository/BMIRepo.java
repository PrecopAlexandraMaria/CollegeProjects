package Repository;

import Domain.BMI;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

public class BMIRepo implements IRepository<BMI> {
    private String URL;
    private Connection conn = null;

    public BMIRepo(String URL) {
        this.URL = URL;
    }

    private void openConnection() {
        try {
            if (conn == null || conn.isClosed())
                conn = DriverManager.getConnection(this.URL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void closeConnection() {
        try{
            if(conn != null && conn.isClosed()) return;
            else {
                conn.close();
                conn = null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void add(BMI elem) throws RepositoryException {
        openConnection();
        try(PreparedStatement ps = conn.prepareStatement("insert into BMI values (?, ?, ?);")) {
            LocalDate date = elem.getDate();
            ps.setDate(1, java.sql.Date.valueOf(date));
            ps.setString(2, elem.getStatus());
            ps.setDouble(3, elem.getValue());
            ps.executeUpdate();
            closeConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Iterator<BMI> iterator() {
        ArrayList<BMI> bmirepo = new ArrayList<>();
        openConnection();
        try(PreparedStatement ps = conn.prepareStatement("select * from BMI");
            ResultSet rs = ps.executeQuery())
        {
            while(rs.next()){
                java.sql.Date sqlDate = rs.getDate("date");
                LocalDate date = sqlDate.toLocalDate();
                String status = rs.getString("status");
                double value = rs.getDouble("value");
                BMI cardio = new BMI(date, status, value);
                bmirepo.add(cardio);
            }
            closeConnection();
            return bmirepo.iterator();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}