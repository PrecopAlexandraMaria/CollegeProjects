package Repository;

import Domain.BP;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;

public class BPRepo implements IRepository<BP> {
    private String URL;
    private Connection conn = null;

    public BPRepo(String URL) {
        this.URL = URL;
    }

    private void openConnection() {
        try {
            if (conn == null || conn.isClosed())
                conn = DriverManager.getConnection(this.URL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void closeConnection() {
        try{
            if(conn != null && conn.isClosed()) return;
            else {
                conn.close();
                conn = null;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void add(BP elem) throws RepositoryException {
        openConnection();
        try(PreparedStatement ps = conn.prepareStatement("insert into BMI values (?, ?, ?, ?);")) {
            LocalDate date = elem.getDate();
            ps.setDate(1, java.sql.Date.valueOf(date));
            ps.setString(2, elem.getStatus());
            ps.setInt(3, elem.getSValue());
            ps.setInt(4, elem.getDValue());
            ps.executeUpdate();
            closeConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public Iterator<BP> iterator() {
        ArrayList<BP> bprepo = new ArrayList<>();
        openConnection();
        try(PreparedStatement ps = conn.prepareStatement("select * from BMI");
            ResultSet rs = ps.executeQuery())
        {
            while(rs.next()){
                java.sql.Date sqlDate = rs.getDate("date");
                LocalDate date = sqlDate.toLocalDate();
                String status = rs.getString("status");
                int svalue = rs.getInt("svalue");
                int dvalue = rs.getInt("dvalue");
                BP cardio = new BP(date, status, svalue, dvalue);
                bprepo.add(cardio);
            }
            closeConnection();
            return bprepo.iterator();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}