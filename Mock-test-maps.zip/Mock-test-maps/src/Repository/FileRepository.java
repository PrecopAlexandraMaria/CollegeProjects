package Repository;

import Domain.MedicalAnalysis;

public abstract class FileRepository<T extends MedicalAnalysis> extends MemoryRepository<T> {
    String fileName;

    protected abstract void readFromFile();
    protected abstract void writeToFile();

    public FileRepository(String fileName) {
        this.fileName = fileName;
        readFromFile();
    }

    @Override
    public void add(T elem) throws RepositoryException {
        super.add(elem);
        writeToFile();
    }
}