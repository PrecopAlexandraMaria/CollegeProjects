package Repository;

import Domain.MedicalAnalysis;
import java.util.Iterator;

public interface IRepository <T extends MedicalAnalysis> {
    void add(T elem) throws RepositoryException;
    Iterator<T> iterator();
}