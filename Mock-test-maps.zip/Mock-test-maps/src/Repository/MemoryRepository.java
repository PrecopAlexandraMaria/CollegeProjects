package Repository;

import Domain.MedicalAnalysis;

import java.util.ArrayList;
import java.util.Iterator;

public class MemoryRepository<T extends MedicalAnalysis> implements IRepository<T> {
    protected ArrayList<T> elements = new ArrayList<>();

    @Override
    public void add(T elem) throws RepositoryException {
        if (elements.contains(elem))
            throw new RepositoryException("Duplicate.");
        elements.add(elem);
    }

    public Iterator<T> iterator() {
        return this.elements.iterator();
    }
}