package Service;

import Domain.BMI;
import Repository.IRepository;
import Repository.RepositoryException;

import java.time.LocalDate;
import java.util.Iterator;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class BMIService {
    private IRepository<BMI> bmirepo;

    public List<BMI> getAllBMISortedByDate() {
        ArrayList<BMI> list = new ArrayList<>();
        Iterator<BMI> it = bmirepo.iterator();
        while (it.hasNext()) list.add(it.next());

        return list.stream()
                .sorted((a, b) -> a.getDate().compareTo(b.getDate()))
                .toList();
    }



    public BMIService(IRepository<BMI> bmirepo) {
        this.bmirepo = bmirepo;
    }

    public void addBMI(LocalDate date, String status, double value) throws RepositoryException {
        BMI d = new BMI(date, status, value);
        this.bmirepo.add(d);
    }

    public ArrayList<BMI> getAllBMI() {
        ArrayList<BMI> bmi = new ArrayList<BMI>();
        Iterator<BMI> it = bmirepo.iterator();
        while(it.hasNext()) {
            bmi.add(it.next());
        }
        return bmi;
    }

    public List<BMI> filterBMI(int month, String stat) {
        ArrayList<BMI> list = new ArrayList<>();
        Iterator<BMI> it = bmirepo.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list.stream()
                .filter(c -> c.getDate().getMonthValue() == month)
                .filter(c -> Objects.equals(c.getStatus(), stat))
                .toList();
    }
}