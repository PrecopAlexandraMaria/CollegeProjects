package Service;

import Domain.BP;
import Repository.IRepository;
import Repository.RepositoryException;

import java.time.LocalDate;
import java.util.Iterator;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class BPService {
    private IRepository<BP> bprepo;

    public List<BP> getAllSortedByDate() {
        ArrayList<BP> list = new ArrayList<>();
        Iterator<BP> it = bprepo.iterator();
        while (it.hasNext()) list.add(it.next());

        return list.stream()
                .sorted((a, b) -> a.getDate().compareTo(b.getDate()))
                .toList();
    }


    public BPService(IRepository<BP> bprepo) {
        this.bprepo = bprepo;
    }

    public void addBP(LocalDate date, String status, int svalue, int dvalue) throws RepositoryException {
        BP d = new BP(date, status, svalue, dvalue);
        this.bprepo.add(d);
    }

    public ArrayList<BP> getAllBP() {
        ArrayList<BP> bp = new ArrayList<BP>();
        Iterator<BP> it = bprepo.iterator();
        while(it.hasNext()) {
            bp.add(it.next());
        }
        return bp;
    }

    public List<BP> filterBP(int month, String stat) {
        ArrayList<BP> list = new ArrayList<>();
        Iterator<BP> it = bprepo.iterator();
        while (it.hasNext()) {
            list.add(it.next());
        }
        return list.stream()
                .filter(c -> c.getDate().getMonthValue() == month)
                .filter(c -> Objects.equals(c.getStatus(), stat))
                .toList();
    }
}