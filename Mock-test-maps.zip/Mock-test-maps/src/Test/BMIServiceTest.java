package Test;

public class BMIServiceTest {
}
