package Ui;

import Domain.BMI;
import Domain.BP;
import Repository.RepositoryException;
import Service.BMIService;
import Service.BPService;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
import java.util.function.Predicate;

public class Console {
    private BMIService bmiserv;
    private BPService bpserv;

    public Console(BMIService bmiserv, BPService bpserv) {
        this.bmiserv = bmiserv;
        this.bpserv = bpserv;
    }

    public void printMenu() {
        System.out.println("1 - Add analysis");
        System.out.println("2 - See all analyses sorted by date");
        System.out.println("3 - Show all analyses with given status and month");
        System.out.println("0 - Exit");
    }

    public void addMedicalAnalysis() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Date(yyyy-mm-dd): ");
        String text = scanner.nextLine();
        LocalDate date = LocalDate.parse(text);
        scanner.nextLine();

        System.out.println("Status: ");
        String status = scanner.nextLine();
        scanner.nextLine();

        System.out.println("What type of MedicalAnalysis (BMI/BP): ");
        String ma = scanner.nextLine();
        if(Objects.equals(ma, "BMI")){
            System.out.println("Resistance: ");
            double value = scanner.nextDouble();

            try {
                this.bmiserv.addBMI(date, status, value);
            }
            catch (RepositoryException e) {
                System.out.println(e.getMessage());
            }
        }
        else if(Objects.equals(ma, "BP")){
            System.out.println("Systolic value: ");
            int svalue = scanner.nextInt();
            System.out.println("Diastolic value: ");
            int dvalue = scanner.nextInt();

            try {
                this.bpserv.addBP(date, status, svalue, dvalue);
            }
            catch (RepositoryException e) {
                System.out.println(e.getMessage());
            }
        }
        else{
            System.out.println("MedicalAnalysis type introduced incorrect.");
            return;
        }
    }

    public void run() {
        while (true)
        {
            printMenu();
            int option = -1;
            System.out.println("Input your option: ");
            Scanner scanner = new Scanner(System.in);
            option = scanner.nextInt();
            scanner.nextLine();
            if (option == 0)
                return;
            switch (option)
            {
                case 1:
                    addMedicalAnalysis();
                    break;
                case 2:
                    System.out.println("BMI MedicalAnalysis: ");
                    for (BMI d: this.bmiserv.getAllBMI())
                        System.out.println(d);

                    System.out.println("BP MedicalAnalysis: ");
                    for (BP d: this.bpserv.getAllBP())
                        System.out.println(d);
                    break;
                case 3:
                    System.out.println("Month: ");
                    int month = scanner.nextInt();
                    scanner.nextLine();

                    System.out.println("Status: ");
                    String stat = scanner.nextLine();
                    scanner.nextLine();

                    System.out.println("BMI MedicalAnalysis:");
                    for (BMI c : bmiserv.filterBMI(month, stat))
                        System.out.println(c);

                    System.out.println("BP MedicalAnalysis:");
                    for (BP s : bpserv.filterBP(month, stat))
                        System.out.println(s);

                    break;
            }
        }
    }
}